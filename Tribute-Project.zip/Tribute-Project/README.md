#Tribute Page - Ratan Tata

This is a simple yet interactive tribute webpage dedicated to Ratan Tata, an inspiring industrialist and philanthropist.

#Tech Stack

- HTML
- CSS
- JavaScript

#Project Structure

/tribute-ratan-tata/
│
├── index.html # Main HTML page
├── style.css # Stylesheet for layout and design
├── script.js # JS for interactivity
├── images/
│ └── ratan-tata.jpg
└── README.md # Project details and instructions

#Features

- Beautiful responsive design
- Interactive admiration list with dynamic JS
- Timeline of major achievements
- Blockquote and styled header section

#Image Note

Replace `images/ratan-tata.jpg` with a real image of Ratan Tata in the `images` folder.

#How to Run

1. Clone or download the repository.
2. Open `index.html` in any web browser.
3. Click the **Add to List** button to add your personal admiration points.

#Acknowledgements

Inspired by the values and legacy of Ratan Naval Tata.