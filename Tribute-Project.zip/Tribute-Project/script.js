const quotes = [
  '"Take the stones people throw at you, and use them to build a monument."',
  '"Power and wealth are not two of my main stakes."',
  '"None can destroy iron, but its own rust can! Likewise, none can destroy a person, but his own mindset can."',
  '"I don’t believe in taking right decisions. I take decisions and then make them right."',
  '"Business need to go beyond the interest of their companies to the communities they serve."'
];

let index = 0;

function nextQuote() {
  index = (index + 1) % quotes.length;
  document.getElementById("quoteBox").innerText = quotes[index];
}
